# PowerPoint transitions and playback

The deck contains native Fade slide transitions. **Native Morph is not embedded.**
Text, shapes, diagrams, a comparison table and the stall chart are editable. Application screenshots and recorded footage remain raster media, preserving the real interface.

## Optional Morph sequences in Microsoft PowerPoint

1. Save a copy of the finished deck in a current desktop version of PowerPoint.
2. Select slide 4, then **Transitions → Morph → Effect Options → Objects**. Set duration to approximately 0.8 seconds. The same overview screenshot on slides 3 and 4 is named `!!ProductFrame` and has been prepared to shrink from product overview into the journey panel. Inspect in Slide Show view.
3. Keep Fade between slides 5 and 6: methodology and implemented architecture use different layouts.
4. Keep Fade for the demo slide (7): morphing a picture into an embedded movie can behave differently between PowerPoint versions. Do not change the movie's media relationship or replace it with a linked local file.
5. Keep Fade on the other slides unless manually rehearsed. Apply Morph only to the target slides, not “Apply to All”.

## Embedded demo playback

- Slide 10 contains the complete H.264 MP4, with an application poster frame, embedded inside the PPTX package.
- Enter Slide Show mode and click the video. If desired, use **Playback → Start → Automatically** in desktop PowerPoint after rehearsal. Click-to-play is the supplied behavior.
- The clip is silent and captioned. Keep the standalone MP4 available as a backup.
- Embedded package relationships and media identity were verified, and the standalone video was decoded and tested in Chromium. Microsoft PowerPoint is not available in this environment; playback inside that application has not been tested.
- The PDF preview is a static slide preview with a video poster, not a playable video deliverable.

## Fonts

Editorial headings: Liberation Serif. Supporting text: DejaVu Sans. If unavailable on the presentation computer, install these open-source fonts or replace them consistently with Times New Roman and Arial, then recheck wrapping. Fonts are not embedded in the PPTX.
