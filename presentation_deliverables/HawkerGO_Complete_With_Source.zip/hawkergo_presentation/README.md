# HawkerGO presentation package

- **HawkerGO_Final_Presentation.pptx** — 12 editable 16:9 slides; complete video embedded on slide 10.
- **HawkerGO_Demo_Video.mp4** — 73.2 seconds, 1920 × 1080, H.264, 30 fps; silent with English captions.
- **HawkerGO_Presentation_Preview.pdf** — all 12 slides, static video poster.
- **HawkerGO_Demo_Subtitles.srt** — timed subtitle cues.
- **HawkerGO_Presentation_Script.md** — speaker script and timing guidance; notes also embedded in slides.
- **HawkerGO_Video_Storyboard.md** — finished sequence and recording details.
- **HawkerGO_Morph_Instructions.md** — supplied Fade transitions and optional Morph steps.
- **assets/** — real app screenshots and branded video assets.
- **source/** — recording, editing, slide-generation and validation scripts, original footage, evidence and rendered QA.

## Before presenting

Open the PPTX in desktop Microsoft PowerPoint, enter Slide Show view and click the video on slide 10. Embedded media identity is verified and the MP4 played in Chromium; desktop PowerPoint was unavailable for direct testing. Fonts used: Liberation Serif and DejaVu Sans; see Morph instructions for substitutions.

Native Morph is **not embedded**. Native Fade is included; matched objects prepare slides 3→4  for optional Morph.

The design-reference PDF exceeded the 32 MiB transfer limit. Its pages could not be inspected. The deck follows the user's detailed burgundy/cream editorial design brief; exact layout fidelity is unverified. Original files remain unchanged.

The attached guide and repository call DS608 “Data Analytics for Economics”; the user's requested title “Cloud Computing” appears on the opening slide. Confirm the correct administrative title before submission. Names follow the repository; Enhui's surname is not documented.

The real footage demonstrates the calendar month selector, dated closure details, Explore date/MRT filters, updated counters, scheduled closure status, nearby alternatives, stall chart and top-ten table. The app's external map tiles and Google fonts were blocked in this environment; no map was fabricated. No production cloud endpoint or live operational feed is claimed. Proposed cloud capabilities are labelled.

Generative AI assisted the presentation, recording automation and editing. The project team should understand, verify and acknowledge this work in its academic submission. Tracked repository files were unchanged. No media was committed, pushed or published.

## Revised presentation structure

1. Opening
2–3. Motivation & Objectives
4. Data Sources & Preparation
5–6. Approach & Methodology
7–10. Dashboard (embedded video on slide 10)
11. Challenges & Limitations
12. Closing

A red five-section navigation bar highlights the active section. The preview PDF is static and excludes media annotations to keep its download small. The PPTX retains the complete embedded MP4. Fresh-named copies are also supplied at `/workspace/HawkerGO_Revised_Presentation.pptx` and `/workspace/HawkerGO_Revised_Preview.pdf`. All files are below 40 MB. A successful download through the chat UI cannot be verified from the execution environment.
