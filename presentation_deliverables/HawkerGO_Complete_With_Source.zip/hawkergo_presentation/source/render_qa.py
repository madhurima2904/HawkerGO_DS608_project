from pathlib import Path
import fitz,subprocess
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1];out=R/'source/rendered'
pdf=out/'HawkerGO_Final_Presentation.pdf'
if pdf.exists():
 d=fitz.open(pdf)
 for i,page in enumerate(d):
  page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(out/f'slide_{i+1:02}.png')
 canvas=Image.new('RGB',(1600,4*320),'#cfc5ba');dr=ImageDraw.Draw(canvas)
 for i in range(len(d)):
  im=Image.open(out/f'slide_{i+1:02}.png');im.thumbnail((520,293));x=(i%3)*535;y=(i//3)*320;canvas.paste(im,(x,y));dr.text((x+8,y+297),f'{i+1:02}',fill='black')
 canvas.save(out/'slide_contact.png')
# Sample actual decoded video frames across transitions and every chapter.
times=[0,3,8,14,21,27,32,40,47,53,60,66,71]
canvas=Image.new('RGB',(1600,5*325),'#cfc5ba');dr=ImageDraw.Draw(canvas)
for i,t in enumerate(times):
 f=out/f'video_{t:02}.jpg'
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(R/'HawkerGO_Demo_Video.mp4'),'-frames:v','1',str(f)],check=True)
 im=Image.open(f);im.thumbnail((520,293));x=(i%3)*535;y=(i//3)*325;canvas.paste(im,(x,y));dr.text((x+8,y+297),f'{t}s',fill='black')
canvas.save(out/'video_contact.png')
