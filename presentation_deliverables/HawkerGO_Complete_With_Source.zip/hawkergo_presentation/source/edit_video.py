"""Edit genuine recorded browser footage; add branded cards, reframing and captions.
Requires FFmpeg, Pillow, and source/recording_manifest.json. No synthetic UI.
"""
import json,subprocess
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'assets';S=ROOT/'source';R=S/'recordings'
BURG='#4B1425'; CREAM='#F5EDDF'; GOLD='#C39B76'
SER='/usr/share/fonts/truetype/liberation2/LiberationSerif-Regular.ttf'
SANS='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=lambda n,ser=False:ImageFont.truetype(SER if ser else SANS,n)
def text(draw,xy,txt,n=30,fill=CREAM,ser=False):draw.text(xy,txt,font=font(n,ser),fill=fill)
def card(name,closing=False):
 im=Image.new('RGB',(1920,1080),BURG);d=ImageDraw.Draw(im);d.rectangle((44,44,1876,1036),outline=GOLD,width=2)
 text(d,(100,92),'SINGAPORE / A BETTER VISIT STARTS HERE',23,GOLD)
 text(d,(100,290),'HAWKERGO',176,CREAM,True)
 d.line((108,535,1810,535),fill=GOLD,width=2)
 text(d,(108,592),'Explore More. Discover Better.' if closing else 'Discover Singapore, One Hawker at a Time',48,CREAM,True)
 text(d,(108,820),'SCHEDULES  /  NEARBY ALTERNATIVES  /  STALL INSIGHTS',25,GOLD)
 text(d,(108,930),'Recorded from the working Streamlit application' if not closing else 'Plan with schedules. Confirm with official notices.',25)
 im.save(A/(name+'.png'))
card('video_open');card('video_close',True)
def bg(name,label,subtitle,left=None):
 im=Image.new('RGB',(1920,1080),BURG);d=ImageDraw.Draw(im)
 d.line((70,80,1850,80),fill=GOLD,width=1);text(d,(72,30),'HAWKERGO',25,CREAM)
 w=d.textlength(label,font=font(22));text(d,(1848-w,32),label,22,GOLD)
 text(d,(95,1004),subtitle,28,CREAM)
 d.line((72,975,1848,975),fill=GOLD,width=1)
 if left:
  for idx,line in enumerate(left):text(d,(100,220+idx*85),line,55 if idx<2 else 28,CREAM if idx<2 else GOLD,idx<2)
 im.save(A/(name+'_bg.png'))
def run(args):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*args],check=True)
def still(name,seconds):
 out=R/(name+'.mp4');run(['-loop','1','-i',str(A/(name+'.png')),'-t',str(seconds),'-vf',f"zoompan=z=1.002:x=iw/2-iw/zoom/2:y=ih/2-ih/zoom/2:d=1:s=1920x1080:fps=30,format=yuv420p",'-r','30','-c:v','libx264','-preset','fast','-crf','19','-threads','4','-an',str(out)]);return out
m=json.loads((S/'recording_manifest.json').read_text());raw=m['video'];raw=raw if Path(raw).exists() else str(R/Path(raw).name);seq=[still('video_open',6)]
settings=[
 ('overview',8,'01 / KNOW BEFORE YOU GO','Start with scheduled closures, then plan your visit.',(300,100,1560,860),None),
 ('calendar',12,'02 / CHECK THE DATE','Choose June 2026 to reveal the recorded cleaning schedule.',(350,70,1500,900),None),
 ('closure',6,'03 / READ THE NOTICE','Chomp Chomp: scheduled cleaning on 22–24 June 2026.',(350,360,1500,570),None),
 ('explore_filters',12,'04 / NARROW THE SEARCH','Set 22 June 2026 and filter by Lorong Chuan MRT.',(350,100,1500,465),None),
 ('alternatives',12,'05 / FIND AN ALTERNATIVE','Serangoon Garden Market is listed about 0.1 km away.',(1260,210,580,735),['A CLOSED','FAVOURITE.','A nearby alternative.','','22 JUNE 2026','Scheduled status,','not real-time availability.']),
 ('insights',12,'06 / COMPARE STALLS','Compare food and market stalls; open the underlying top-ten table.',(350,100,1500,860),None)
]
# Crops are authentic screen regions, with aspect ratio preserved throughout.
for name,dur,label,sub,crop,left in settings:
 item=next(t for t in m['markers'] if t['name']==name);span=item['end']-item['start']
 bg(name,label,sub,left)
 x,y,w,h=crop
 maxw,maxh=(760,810) if left else (1728,830)
 scale=min(maxw/w,maxh/h);ow=int(w*scale)//2*2;oh=int(h*scale)//2*2
 ox=1030 if left else (1920-ow)//2;oy=110+(830-oh)//2
 # Subtle 2% camera push on the actual footage, followed by a restrained dissolve.
 vf=f"[1:v]trim=start={item['start']}:end={item['end']},setpts=(PTS-STARTPTS)*{dur/span},crop={w}:{h}:{x}:{y},scale={ow}:{oh},fps=30,zoompan=z='1+0.018*on/{dur*30}':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s={ow}x{oh}:fps=30[v];[0:v][v]overlay={ox}:{oy}:shortest=1,format=yuv420p[out]"
 if name=='explore_filters':
  vf=vf.replace('format=yuv420p[out]', "drawbox=x=146:y=466:w=272:h=51:color=0xC39B76:t=3:enable='between(t,1,4)',drawbox=x=435:y=466:w=358:h=51:color=0xC39B76:t=3:enable='between(t,5,9)',format=yuv420p[out]")
 out=R/(name+'_edit.mp4')
 run(['-loop','1','-i',str(A/(name+'_bg.png')),'-i',raw,'-filter_complex',vf,'-map','[out]','-t',str(dur),'-r','30','-c:v','libx264','-preset','fast','-crf','19','-threads','4','-an',str(out)])
 seq.append(out)
seq.append(still('video_close',8))
# Full-frame crossfades, keeping UI pixels and captions crisp.
durations=[6]+[t[1] for t in settings]+[8];fade=.4
args=[]
for p in seq:args+=['-i',str(p)]
filters=[];prev='0:v';offset=durations[0]-fade
for i in range(1,len(seq)):
 out=f'v{i}';filters.append(f'[{prev}][{i}:v]xfade=transition=fade:duration={fade}:offset={offset:.3f}[{out}]');prev=out;offset+=durations[i]-fade
run([*args,'-filter_complex_threads','2','-filter_complex',';'.join(filters),'-map',f'[{prev}]','-r','30','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart','-threads','4','-an',str(ROOT/'HawkerGO_Demo_Video.mp4')])
# The captions are burned into chapter frames; SRT includes title/closing accessibility.
def tc(x):
 ms=round(x*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
texts=['HawkerGO — Discover Singapore, One Hawker at a Time']+[x[3] for x in settings]+['HawkerGO — Explore More. Discover Better. Confirm official notices before visiting.']
t=0;lines=[]
for i,(d,tx) in enumerate(zip(durations,texts)):
 start=t if i==0 else t+.2;end=t+d-(.2 if i<len(texts)-1 else 0)
 lines.append(f'{i+1}\n{tc(start)} --> {tc(end)}\n{tx}\n');t+=d-fade
(ROOT/'HawkerGO_Demo_Subtitles.srt').write_text('\n'.join(lines))
run(['-ss','9','-i',str(ROOT/'HawkerGO_Demo_Video.mp4'),'-frames:v','1',str(A/'video_poster.png')])
(S/'edit_manifest.json').write_text(json.dumps({'duration':sum(durations)-fade*(len(durations)-1),'scenes':settings,'transitions':'0.4 s crossfade','audio':'silent; burned-in English captions'},indent=2))
print('Video complete',sum(durations)-fade*(len(durations)-1))
