from pathlib import Path
import sys,json,subprocess
ROOT=Path('/workspace/HawkerGO_DS608_project');sys.path.insert(0,str(ROOT))
import pandas as pd
from src.wrangle import load_closure_data
x=pd.read_csv(ROOT/'data/processed/hawker_centres_final.csv');x['total']=x.no_of_food_stalls+x.no_of_market_stalls
e=load_closure_data()
d={'commit':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),'centres':len(x),'food_stalls':int(x.no_of_food_stalls.sum()),'events':len(e),'dated':int((e['Schedule Status']=='Dated').sum()),'review':int((e['Schedule Status']=='Needs review').sum()),'top5':x.nlargest(5,'total')[['name','no_of_food_stalls','no_of_market_stalls','total']].to_dict('records')}
Path(__file__).with_name('project_evidence.json').write_text(json.dumps(d,indent=2))
print(json.dumps(d,indent=2))
