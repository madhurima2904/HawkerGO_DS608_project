# Reproduce HawkerGO presentation and demo

All output lives outside the Git checkout. No application source or reference PDF is changed. The full design-reference PDF could not be transferred because it exceeds the tool's 32 MiB limit; the design follows the user's written brief (burgundy, cream, editorial serif headings, alternating light/dark slides, thin borders). Exact PDF-layout fidelity could not be assessed.

## Tools

- Python 3.12; python-pptx, Pillow, pandas, Playwright, PyMuPDF (see `requirements-tools.txt`).
- Chromium (`/usr/bin/chromium`) and FFmpeg/FFprobe on PATH.
- A PowerPoint-compatible renderer for PDF export. LibreOffice 25.2.3 was extracted locally to `/workspace/lo` for this session; use an ordinary LibreOffice installation elsewhere.
- The separate app environment: `/workspace/HawkerGO_DS608_project/.venv`, installed from the repository's pinned `requirements.txt`.

## Run

From the existing checkout, start:

```bash
cd /workspace/HawkerGO_DS608_project
.venv/bin/python -m streamlit run app.py --server.headless=true --server.address=127.0.0.1 --server.port=8501 --browser.gatherUsageStats=false
```

In another terminal:

```bash
cd /workspace/hawkergo_presentation
python source/project_evidence.py
PLAYWRIGHT_BROWSERS_PATH=/workspace/pw-browsers python source/record_demo.py
python source/edit_video.py
python source/build_presentation.py
```

Playwright video recording requires its FFmpeg executable. In this machine, `/workspace/pw-browsers/ffmpeg-1011/ffmpeg-linux` points to `/usr/bin/ffmpeg`. On another machine, use the supported `python -m playwright install chromium` command or update the explicit browser executable in the recording script.

The source-time manifest retains the original recording path. `edit_video.py` falls back to the same filename under `source/recordings` if the package is moved. `project_evidence.py` expects the checkout in its documented workspace location; adjust that one constant if needed.

Export PDF without resaving the PPTX through the renderer:

```bash
libreoffice --headless --convert-to pdf --outdir source/rendered HawkerGO_Final_Presentation.pptx
python source/export_preview.py
python source/render_qa.py
python source/validate_deliverables.py
```

Local renderer used in this environment:

```bash
LD_LIBRARY_PATH=/workspace/lo/usr/lib/libreoffice/program:/workspace/lo/usr/lib/x86_64-linux-gnu /workspace/lo/usr/lib/libreoffice/program/soffice -env:UserInstallation=file:///workspace/lo-profile --headless --convert-to pdf --outdir /workspace/hawkergo_presentation/source/rendered /workspace/hawkergo_presentation/HawkerGO_Final_Presentation.pptx
```

## Evidence and limitations

- `project_evidence.json`: dataset-derived counts and exact repository revision.
- `recording_manifest.json`: authentic footage and marked scene source intervals.
- `edit_manifest.json`: final editing specification and duration.
- `rendered/`: slide renders, sampled video frames and contact sheets for QA.
- `validation_report.json`: structural, media, subtitle, PDF and slide checks.
- App basemap requests and Google fonts were denied by the configured network policy. No workaround or fake map was used.
- No deployed cloud endpoint, original public source URLs, publication dates or dataset licences were verified. These are disclosed in the slides/notes.
- The guide and repository call DS608 “Data Analytics for Economics”; the user's requested course title “Cloud Computing” is used on the opening slide. Confirm before assessment.
- Names and page responsibilities derive from README and CONTRIBUTIONS. Only “Enhui” is documented; no surname was invented.
- Original `AI_USAGE.md` is empty. This package acknowledges AI-assisted production; the team should update its submission statement separately if appropriate.
- The source screenshot assets are genuine app captures. No third-party fashion photographs or reference branding are included. Screenshot reuse is limited to the user's own project presentation; underlying dataset licensing still requires verification by the project team.

## Updated section structure

The deck follows the supplied five-section navigation: Motivation & Objectives (slides 2–3), Data Sources & Preparation (4), Approach & Methodology (5–6), Dashboard (7–10), and Challenges & Limitations (11), with an opening and closing slide. The embedded video is now on slide 10.
