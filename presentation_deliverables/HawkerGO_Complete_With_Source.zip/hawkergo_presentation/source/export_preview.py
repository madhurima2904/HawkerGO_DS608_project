from pathlib import Path
import fitz
r=Path(__file__).resolve().parents[1]
src=fitz.open(r/'source/rendered/HawkerGO_Final_Presentation.pdf')
out=fitz.open()
out.insert_pdf(src,annots=False)
out.save(r/'HawkerGO_Presentation_Preview.pdf',garbage=4,deflate=True)
