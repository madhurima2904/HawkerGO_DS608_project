"""Inspect final PPTX/media, PDF, SRT and output invariants without modifying them."""
from pathlib import Path
import zipfile,json,hashlib,subprocess,re
from lxml import etree
from pptx import Presentation
import fitz
R=Path(__file__).resolve().parents[1];ppt=R/'HawkerGO_Final_Presentation.pptx';mp4=R/'HawkerGO_Demo_Video.mp4'
report={};p=Presentation(ppt);assert len(p.slides)==12
assert abs(p.slide_width/p.slide_height-16/9)<1e-5
report['slides']=12;report['aspect_ratio']='16:9'
report['editable_text_boxes']=sum(1 for s in p.slides for sh in s.shapes if sh.has_text_frame)
report['native_charts']=sum(1 for s in p.slides for sh in s.shapes if sh.has_chart)
report['native_tables']=sum(1 for s in p.slides for sh in s.shapes if sh.has_table)
assert report['native_charts']==1 and report['native_tables']==1
bounds=[]
for i,s in enumerate(p.slides):
 assert s.has_notes_slide
 for sh in s.shapes:
  if sh.left < 0 or sh.top < 0 or sh.left+sh.width > p.slide_width+100 or sh.top+sh.height > p.slide_height+100:bounds.append((i+1,sh.name))
assert not bounds,bounds
report['all_shapes_within_slide']=True
with zipfile.ZipFile(ppt) as z:
 for n in z.namelist():
  if n.endswith('.xml') or n.endswith('.rels'):etree.fromstring(z.read(n))
 media=[n for n in z.namelist() if n.endswith('.mp4')]
 assert len(media)==1,media
 assert hashlib.sha256(z.read(media[0])).digest()==hashlib.sha256(mp4.read_bytes()).digest()
 report['embedded_video']=media[0];report['embedded_video_identical_to_standalone']=True
 ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
 assert 'videoFile' in p.slides[9]._element.xml
 video_parts=[n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide[0-9]+\.xml',n) and b'videoFile' in z.read(n)]
 assert len(video_parts)==1
 video_part=video_parts[0]
 slide7=etree.fromstring(z.read(video_part))
 assert slide7.xpath('count(//a:videoFile)',namespaces=ns)==1
 rel=etree.fromstring(z.read('ppt/slides/_rels/'+Path(video_part).name+'.rels'))
 assert any('media' in r.get('Type','') and r.get('TargetMode')!='External' for r in rel)
 report['video_relationship']='internal embedded media with poster and timing'
 report['native_fade_transitions']=sum(b'<p:fade' in z.read(f'ppt/slides/slide{i}.xml') for i in range(1,13))
 report['native_morph']=False
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,r_frame_rate,pix_fmt','-show_entries','format=duration,size','-of','json',str(mp4)],text=True))
v=info['streams'][0];assert v['codec_name']=='h264' and (v['width'],v['height'])==(1920,1080) and v['r_frame_rate']=='30/1'
report['video']=info;assert abs(float(info['format']['duration'])-73.2)<.05
subprocess.run(['ffmpeg','-v','error','-i',str(mp4),'-f','null','-'],check=True)
report['full_video_decode']='passed'
srt=(R/'HawkerGO_Demo_Subtitles.srt').read_text()
entries=re.findall(r'(\d\d):(\d\d):(\d\d),(\d\d\d) --> (\d\d):(\d\d):(\d\d),(\d\d\d)',srt)
assert len(entries)==8
previous=0
for e in entries:
 a=list(map(int,e));start=a[0]*3600+a[1]*60+a[2]+a[3]/1000;end=a[4]*3600+a[5]*60+a[6]+a[7]/1000
 assert start>=previous and end>start and end<=73.201
 previous=end
report['subtitle_cues']=8;report['subtitle_times_valid']=True
pdf=R/'HawkerGO_Presentation_Preview.pdf';doc=fitz.open(pdf);assert len(doc)==12
report['pdf_pages']=len(doc);report['pdf_text_characters']=sum(len(x.get_text()) for x in doc)
assert report['pdf_text_characters']>3000
report['powerpoint_playback']='not available; desktop PowerPoint not installed'
report['reference_pdf']='transfer blocked: exceeds 32 MiB; visual design based on user brief'
report['git_status']=subprocess.check_output(['git','-C','/workspace/HawkerGO_DS608_project','status','--porcelain'],text=True).strip()
assert report['git_status']==''
(R/'source/validation_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
