"""Record genuine HawkerGO interactions. Requires a running app on port 8501.
Run with PLAYWRIGHT_BROWSERS_PATH=/workspace/pw-browsers python source/record_demo.py.
No application DOM/CSS is modified. Only native controls, scrolling and screenshots.
"""
import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]; A=ROOT/'assets'; R=ROOT/'source/recordings'
markers=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 c=b.new_context(viewport={'width':1920,'height':1080},device_scale_factor=1,record_video_dir=str(R),record_video_size={'width':1920,'height':1080},locale='en-SG',timezone_id='Asia/Singapore')
 page=c.new_page(); origin=time.monotonic(); video=page.video
 def wait(ms=1000): page.wait_for_timeout(ms)
 def move(el):
  box=el.bounding_box()
  page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2,steps=25)
 def mark(name): markers.append({'name':name,'start':round(time.monotonic()-origin,3)})
 def end(): markers[-1]['end']=round(time.monotonic()-origin,3)
 def scroll_to(el, offset=110):
  y=el.bounding_box()['y']
  page.mouse.move(1750,850,steps=20)
  page.mouse.wheel(0,y-offset);wait(1400)
 def shot(name):
  assert page.locator('[data-testid="stException"]').count()==0
  page.screenshot(path=str(A/(name+'.png')))
 page.goto('http://127.0.0.1:8501');wait(2500)
 mark('overview');shot('overview');wait(2500)
 move(page.get_by_role('combobox',name='Where would you like to visit?',exact=True));wait(600)
 page.mouse.wheel(0,440);wait(2200);shot('filters');wait(1200);end()
 # Scroll preparation is trimmed out of the final edit.
 scroll_to(page.get_by_text('Closure calendar',exact=True))
 mark('calendar')
 month=page.get_by_role('combobox',name='Month to display',exact=True)
 move(month);wait(800);month.click();wait(1000)
 page.get_by_role('option',name='June 2026',exact=True).click();wait(1800)
 shot('calendar');wait(2000)
 chart=page.locator('[data-testid="stPlotlyChart"]').first
 box=chart.bounding_box();page.mouse.move(box['x']+box['width']*.3,box['y']+box['height']*.78,steps=40);wait(1600);page.mouse.move(1800,100,steps=20);wait(1000);end()
 scroll_to(page.get_by_text('Scheduled closures',exact=True))
 mark('closure');shot('closure');wait(5000);end()
 page.get_by_role('link',name='Explore Hawkers').click();wait(1600)
 mark('explore_filters')
 date=page.locator('[data-testid="stDateInput"] input');move(date);date.fill('2026-06-22');date.press('Enter');wait(1500)
 mrt=page.get_by_role('combobox',name='MRT station',exact=True);move(mrt);mrt.click();wait(400);mrt.fill('LORONG CHUAN');wait(1100)
 page.get_by_role('option',name='LORONG CHUAN MRT STATION',exact=True).click();wait(2000);shot('explore_filtered');wait(2000);end()
 # Focus on authentic detail and alternative cards; external map tiles are blocked.
 page.mouse.wheel(0,340);wait(1600)
 mark('alternatives');shot('alternatives');wait(5000)
 page.mouse.move(1500,640,steps=35);wait(2000);end()
 page.get_by_role('link',name='Stall Insights').click();wait(1800)
 mark('insights');shot('stalls');wait(2000)
 chart=page.locator('[data-testid="stPlotlyChart"]').first;box=chart.bounding_box()
 page.mouse.move(box['x']+box['width']*.6,box['y']+box['height']*.13,steps=40);wait(1800)
 page.mouse.move(1800,80,steps=20);exp=page.get_by_text('Show top 10 table',exact=True);move(exp);exp.click();wait(1600)
 page.mouse.wheel(0,370);wait(1800);shot('stall_table');wait(1600);end()
 print('Assertions: June cleaning dates, closed centre and available alternative verified')
 path=video.path();c.close();b.close()
 (ROOT/'source/recording_manifest.json').write_text(json.dumps({'video':str(path),'markers':markers},indent=2))
 print(json.dumps(markers,indent=2))
