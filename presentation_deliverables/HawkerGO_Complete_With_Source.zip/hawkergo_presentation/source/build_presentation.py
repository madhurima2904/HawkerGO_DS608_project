"""Generate editable 16:9 HawkerGO slides with python-pptx.
Run after record_demo.py and edit_video.py. Source data is in project_evidence.json.
"""
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR,PP_ALIGN
from pptx.enum.chart import XL_CHART_TYPE,XL_LEGEND_POSITION,XL_LABEL_POSITION
from pptx.chart.data import CategoryChartData
from pptx.oxml.xmlchemy import OxmlElement
from PIL import Image
import json
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'assets';S=ROOT/'source'
E=json.loads((S/'project_evidence.json').read_text())
B='4B1425';C='F5EDDF';G='B78F70';INK='302326';M='786968';PALE='E9DDCD';WHITE='FFFCF7'
SER='Liberation Serif';SANS='DejaVu Sans'
p=Presentation();p.slide_width=Inches(13.333333);p.slide_height=Inches(7.5)
p.core_properties.title='HawkerGO — Discover Singapore, One Hawker at a Time'
p.core_properties.subject='DS608: a verified application walkthrough and cloud deployment considerations'
p.core_properties.author='HawkerGO group | presentation prepared with AI assistance'
p.core_properties.keywords='HawkerGO, Streamlit, DS608, editable, embedded demo'
notes=[]
def rgb(s):return RGBColor.from_string(s)
def rect(sl,x,y,w,h,fill=None,line=None,lw=.7,name=None):
 sh=sl.shapes.add_shape(MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h))
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=rgb(fill)
 else:sh.fill.background()
 if line:sh.line.color.rgb=rgb(line);sh.line.width=Pt(lw)
 else:sh.line.fill.background()
 sh._element.spPr.append(OxmlElement('a:effectLst'))
 if name:sh.name=name
 return sh
def txt(sl,text,x,y,w,h,size=20,color=INK,font=SANS,bold=False,align=PP_ALIGN.LEFT,name=None):
 box=sl.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=box.text_frame
 tf.clear();tf.margin_left=tf.margin_right=0;tf.margin_top=tf.margin_bottom=0;tf.word_wrap=True
 for idx,line in enumerate(text.split('\n')):
  q=tf.paragraphs[0] if idx==0 else tf.add_paragraph();q.text=line;q.font.name=font;q.font.size=Pt(size);q.font.bold=bold;q.font.color.rgb=rgb(color);q.alignment=align;q.space_after=Pt(4)
 if name:box.name=name
 return box
def line(sl,x1,y1,x2,y2,color=G,lw=.7):
 sh=sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2));sh.line.color.rgb=rgb(color);sh.line.width=Pt(lw);return sh
def pic(sl,path,x,y,w,h,name=None):
 im=Image.open(path);iw,ih=im.size;scale=min(w/iw,h/ih);nw=iw*scale;nh=ih*scale
 sh=sl.shapes.add_picture(str(path),Inches(x+(w-nw)/2),Inches(y+(h-nh)/2),width=Inches(nw),height=Inches(nh))
 if name:sh.name=name
 return sh
def base(n,dark=False,section=''):
 sl=p.slides.add_slide(p.slide_layouts[6]);sl.background.fill.solid();sl.background.fill.fore_color.rgb=rgb(B if dark else C)
 col=C if dark else B
 rect(sl,.23,.23,12.87,7.04,line=G,lw=.6)
 # Five-section navigation follows the user's supplied content bar.
 rect(sl,0,0,13.333333,.84,'800900')
 labels=['MOTIVATION &\nOBJECTIVES','DATA SOURCES &\nPREPARATION','APPROACH &\nMETHODOLOGY','DASHBOARD','CHALLENGES & LIMITATIONS']
 positions=[(.33,2.25),(2.83,2.25),(5.22,2.25),(7.72,2.05),(10.27,2.78)]
 active={2:0,3:0,8:1,10:2,9:2,4:3,5:3,6:3,7:3,11:4,12:4}.get(n)
 for j,(label,(x,w)) in enumerate(zip(labels,positions)):
  txt(sl,label,x,.18,w,.53,10.5,'FFFCF7' if active in [None,j] else 'D7B4A6',bold=True,name=f'SectionNavigation{j}')
  if active==j:line(sl,x,.74,x+w,.74,'F5EDDF',2)

 line(sl,.55,6.98,12.78,6.98,G)
 txt(sl,'DS608  /  GROUP PROJECT 2026',.55,7.1,8,.18,8,G)
 txt(sl,f'{n:02}',12.0,7.08,.75,.2,9,col,align=PP_ALIGN.RIGHT,name='SlideNumber')
 transition=OxmlElement('p:transition');transition.set('spd','med');transition.append(OxmlElement('p:fade'))
 sl._element.append(transition)
 return sl

def note(sl,title,body,seconds):
 text=f'{title} | {seconds} seconds\n\n{body}'
 sl.notes_slide.notes_text_frame.text=text
 notes.append((title,body,seconds))

# 01 — Opening
s=base(1,True,'Singapore / a better visit starts here')
txt(s,'Discover Singapore,\none hawker at a time.',.65,1.05,7.4,1.6,42,C,SER)
txt(s,'HAWKERGO',.55,2.65,12.3,1.45,92,C,SER,name='!!BrandTitle')
line(s,.65,4.35,7.5,4.35)
txt(s,'Plan with schedules.\nFind a nearby alternative.',.68,4.62,5.9,1.02,27,C,SER)
txt(s,'DS608 CLOUD COMPUTING',.68,6.0,6,.3,13,G,bold=True)
txt(s,'Madhurima Subramaniam Rudra (Madhu)\nNicolyne Tiana Lie  ·  Enhui',.68,6.35,7,.5,12,C)
pic(s,A/'calendar_crop.png',8.2,4.35,4.45,2.35,'!!ProductFrame')
note(s,'Opening',"A good hawker visit starts before we leave home. HawkerGO brings scheduled closures, nearby alternatives and stall information into one Streamlit dashboard. Our focus is practical: help a resident check a plan and find another option when a favourite centre is scheduled to close. This is a group project by Madhurima Subramaniam Rudra, known as Madhu, Nicolyne Tiana Lie and Enhui. Today we will follow five sections: motivation and objectives, data sources and preparation, approach and methodology, the dashboard, and challenges and limitations.",40)

# 02 — Problem
s=base(2,False,'01 / The problem')
txt(s,"Good food shouldn't\nbe hard to plan for.",.65,1.0,8.4,1.7,45,B,SER)
for i,(num,head,body) in enumerate([('01','A favourite may be closed.','Cleaning and other works affect visit plans.'),('02','The next option needs context.','Location, walking distance and scheduled status matter.'),('03','Centre size can mislead.','Food stalls and market stalls serve different needs.')]):
 y=3.15+i*1.08;line(s,.7,y-.12,8.25,y-.12, G);txt(s,num,.7,y,.6,.4,16,G);txt(s,head,1.45,y,6.7,.42,24,B,SER);txt(s,body,1.45,y+.47,6.7,.4,13,M)
rect(s,9.0,1.1,3.6,5.52,B)
txt(s,'THE QUESTION',9.3,1.5,3,.3,11,G,bold=True)
txt(s,'Can public\nschedules\nbecome a\nbetter visit\ndecision?',9.3,2.13,3,3.35,35,C,SER)
txt(s,'A planning problem grounded in public schedules.',9.3,6.05,2.9,.5,10,G)
note(s,'The problem',"The problem is a decision, rather than a lack of restaurant recommendations. A resident may know where they want to eat but still need to know whether a scheduled cleaning period overlaps their visit. If it does, they need another centre nearby. A large centre is also not automatically the best choice for cooked food: total stalls combine food and market stalls. Our research question is how public closure data can be transformed into an interactive dashboard for visit planning. We do not estimate wasted journeys or claim measured time savings; those would require separate user research.",45)

# 03 — Product
s=base(3,True,'02 / The solution')
txt(s,'Our objective:\na better visit plan.',.65,1.0,5.1,1.65,46,C,SER)
txt(s,'Three connected views.\nOne practical decision.',.7,3.0,4.5,1.1,25,C,SER)
for i,(v,l) in enumerate([('123','centres in the included dataset'),('3','interactive dashboard pages')]):
 y=4.45+i*1.0;txt(s,v,.7,y,1.25,.75,44,G,SER);txt(s,l,2.05,y+.18,3.0,.6,13,C)
rect(s,5.7,1.15,6.95,5.5,line=G)
pic(s,A/'overview_crop.png',5.83,1.28,6.69,5.22,'!!ProductFrame')
note(s,'Meet HawkerGO',"HawkerGO combines three views of the same planning problem. Explore Hawkers supports date, MRT and status filtering, centre details and nearby alternatives. The Maintenance Calendar presents cleaning and other works over time. Stall Insights compares the distribution of food and market stalls. There are 123 centre records in the included processed dataset. These are dataset coverage figures, not a claim about complete current national coverage. The screenshot is captured from the working app. Its status labels are computed from uploaded schedules, so they must not be interpreted as a live operational feed.",45)

# 04 — Journey
s=base(4,False,'03 / The experience')
txt(s,'From “is it closed?”\nto “where next?”',.65,1.0,7.8,1.55,45,B,SER)
pic(s,A/'overview_crop.png',8.8,1.0,3.8,1.75,'!!ProductFrame')
steps=[('01','CHECK','Maintenance Calendar','Serangoon / June 2026','22–24 June: Chomp Chomp cleaning'),('02','FILTER','Explore Hawkers','22 June / Lorong Chuan MRT','Chosen centre is scheduled closed'),('03','DECIDE','Alternative stall finder','Serangoon Garden Market','Listed distance: about 0.1 km')]
for i,(n,h,sub,a,b) in enumerate(steps):
 x=.7+i*4.17;rect(s,x,3.0,3.85,3.0,None,G);txt(s,n,x+.23,3.25,.8,.7,38,G,SER)
 txt(s,h,x+.23,4.08,3.3,.5,25,B,bold=True);txt(s,sub,x+.23,4.65,3.35,.37,14,B)
 txt(s,a,x+.23,5.19,3.35,.4,12,M);txt(s,b,x+.23,5.62,3.35,.45,11,M)
 if i<2:txt(s,'→',x+3.9,4.2,.28,.5,20,B)
txt(s,'An illustrative journey using dates in the included schedule, not a current operating-status guarantee.',.72,6.4,11.8,.3,11,M)
note(s,'The user journey',"Here is the journey demonstrated in the video. First, check the Maintenance Calendar for Serangoon in June 2026. It records a Chomp Chomp cleaning closure from the twenty-second to the twenty-fourth. Next, set the Explore page to the twenty-second of June and filter for Lorong Chuan MRT. The selected centre is marked closed according to that schedule. Finally, inspect the alternative finder: Serangoon Garden Market is listed about one tenth of a kilometre away. This is an illustrative historical scenario from the supplied data, rather than advice that either centre is open right now. Distances and walking times are estimates.",40)

# 05 — Feature detail
s=base(5,False,'04 / Explore Hawkers')
txt(s,'A closed favourite.\nA nearby alternative.',.65,1.0,8.0,1.55,43,B,SER)
pic(s,A/'explore_controls.png',.7,2.9,7.15,2.25,'!!ProductFrame')
line(s,.7,5.45,7.85,5.45)
txt(s,'DATE + MRT + STATUS',.72,5.65,6.8,.35,13,B,bold=True)
txt(s,'Filter the visit, read the centre details,\nthen compare the listed alternatives.',.72,6.12,6.8,.65,18,INK,SER)
rect(s,8.5,1.15,4.1,5.55,line=G)
pic(s,A/'alternative_crop.png',8.58,1.23,3.94,5.39)
note(s,'Explore Hawkers',"Explore Hawkers begins with the visit date, an MRT station, a status filter and a selected centre. The summary cards update for the MRT-filtered group. The detail card shows address, scheduled status, future cleaning information, stall counts and an estimated walk from the nearest MRT. The alternative finder uses an included centre-to-centre distance matrix and ranks three centres that have no closure recorded for the selected day. The implementation does not ask a routing service for each visit. The map is implemented in Plotly, but external basemap requests are blocked in this recording environment, so the demonstration focuses on the working controls and detail cards.",50)

# 06 — Analysis
s=base(6,True,'05 / Stall Insights')
txt(s,'A centre’s size is only\npart of the story.',.65,1.0,10.7,1.55,44,C,SER)
txt(s,'Chinatown Complex: 703 total stalls',.7,2.75,8.4,.4,21,C,SER)
data=CategoryChartData();data.categories=['Chinatown Complex','Tekka Centre','Geylang Serai','Tiong Bahru','85 Fengshan']
data.add_series('Food stalls',[r['no_of_food_stalls'] for r in E['top5']]);data.add_series('Market stalls',[r['no_of_market_stalls'] for r in E['top5']])
chart=s.shapes.add_chart(XL_CHART_TYPE.BAR_STACKED,Inches(.65),Inches(3.3),Inches(8.2),Inches(3.2),data).chart
chart.has_legend=True;chart.legend.position=XL_LEGEND_POSITION.BOTTOM;chart.legend.include_in_layout=False
chart.legend.font.name=SANS;chart.legend.font.size=Pt(10);chart.legend.font.color.rgb=rgb(C)
for series,col in zip(chart.series,[G,'873D50']):series.format.fill.solid();series.format.fill.fore_color.rgb=rgb(col);series.format.line.fill.background()
chart.category_axis.tick_labels.font.size=Pt(11);chart.category_axis.tick_labels.font.name=SANS;chart.category_axis.tick_labels.font.color.rgb=rgb(C)
chart.category_axis.reverse_order=True
chart.value_axis.maximum_scale=750;chart.value_axis.major_unit=250;chart.value_axis.tick_labels.font.size=Pt(9);chart.value_axis.tick_labels.font.color.rgb=rgb(G)
chart.value_axis.has_major_gridlines=False
for axis in [chart.category_axis,chart.value_axis]:axis.format.line.fill.background()
line(s,9.22,3.35,9.22,6.5,G)
txt(s,'226',9.65,3.45,2.5,.9,54,C,SER);txt(s,'food stalls',9.67,4.35,2.4,.4,15,C)
txt(s,'477',9.65,5.0,2.5,.9,54,G,SER);txt(s,'market stalls',9.67,5.9,2.4,.4,15,C)
txt(s,'Included dataset • top five by total stalls • counts are not quality or popularity measures.',.72,6.65,11.9,.22,9,G)
note(s,'What stall counts reveal',"The Stall Insights page gives us a useful analytical distinction. In the included data, Chinatown Complex has the largest total count: 703 stalls. That comprises 226 food stalls and 477 market stalls. So ranking only by total size can obscure what a visitor wants to do. The stacked bars make the composition visible, while the app also provides a top-ten table and a scatter plot of food versus market stalls. These counts describe the dataset, not popularity, food quality or sales. In this slide the chart is a native editable PowerPoint chart with its underlying values, rather than an image of a chart.",45)

# 07 — Actual embedded video
s=base(7,True,'06 / Recorded application demonstration')
txt(s,'HawkerGO in action',.65,.82,8.4,.56,32,C,SER)
txt(s,'CLICK TO PLAY  /  1:13  /  CAPTIONED',9.3,.96,3.3,.3,9,G,align=PP_ALIGN.RIGHT)
video=ROOT/'HawkerGO_Demo_Video.mp4'
if not video.exists():raise FileNotFoundError('Run edit_video.py first')
s.shapes.add_movie(str(video),Inches(2.0),Inches(1.50),Inches(9.333),Inches(5.25),poster_frame_image=str(A/'video_poster.png'),mime_type='video/mp4').name='!!ProductFrame'
note(s,'Demo — play video',"Play the embedded video. The silent, captioned recording shows genuine interactions with the locally running Streamlit application: choose June, read the cleaning dates, filter Explore Hawkers by date and MRT, inspect the alternative finder, and open the stall-count table. Allow the complete 73.2-second clip to finish. Do not speak over the subtitles unless clarification is useful. After playback, explain that the example uses scheduled status rather than a real-time feed.",80)

# 08 — Data
s=base(8,False,'07 / Behind the experience')
txt(s,'Public records.\nDecision-ready views.',.65,1.0,8.2,1.55,44,B,SER)
pic(s,A/'overview_crop.png',9.25,1.05,3.3,1.65,'!!ProductFrame')
cols=[(.7,'INPUTS','Closure CSV','123 centre records\nDates, remarks, location, stalls'),(4.88,'PREPARATION','Event-level cleaning','Parse quarterly date pairs\nClassify valid and review records'),(9.06,'APPLICATION','Feature-ready tables','Calendar events\nCentre attributes + distance matrix')]
for x,label,title,body in cols:
 rect(s,x,3.0,3.55,2.45,None,G);txt(s,label,x+.2,3.22,3.1,.25,10,G,bold=True);txt(s,title,x+.2,3.72,3.1,.5,23,B,SER);txt(s,body,x+.2,4.5,3.1,.7,13,M)
for x in [4.35,8.53]:txt(s,'→',x,4.0,.45,.5,24,B)
for x,v,l in [(.75,'539','closure event records'),(4.9,'513','valid dated events'),(9.1,'26','records needing review')]:
 txt(s,v,x,5.78,1.45,.7,36,B,SER);txt(s,l,x+1.45,5.98,2.15,.6,12,M)
txt(s,'Local GeoJSON files cover hawker centres and MRT exits. Original source URLs, dates and licences still need verification.',.72,6.65,12,.2,9,M)
note(s,'Data and preparation',"The repository includes a raw closure CSV with 123 centre records, plus hawker-centre and MRT-exit GeoJSON files. The closure loader in src/wrangle.py reshapes quarterly cleaning and other-works date pairs into 539 event records. Of these, 513 have valid date ranges and 26 require review. It parses day-month-year dates, computes inclusive duration and retains remarks. The Explore and Stall Insights pages read the processed centre CSV; the alternative finder also reads a 123-by-123 distance matrix. The complete lineage of those processed files is not documented. Original dataset URLs, publication dates and licences remain a verification task; we do not invent them here.",50)

# 09 — Architecture
s=base(9,True,'08 / Implemented architecture')
txt(s,'A small, transparent stack.',.65,1.0,11.9,.9,43,C,SER)
def node(x,y,w,h,title,body,fill=None):
 rect(s,x,y,w,h,fill or B,G);txt(s,title,x+.2,y+.18,w-.4,.4,20,C,SER);txt(s,body,x+.2,y+.77,w-.4,h-.83,12,C)
node(.7,2.6,2.5,1.95,'Browser','Controls, tables\nand chart interactions')
node(4.0,2.2,4.7,2.8,'Streamlit / Python','app.py → st.navigation\nExplore · Calendar · Stall Insights\nPandas transforms + Plotly charts\nst.cache_data for selected loaders')
node(9.5,2.6,3.1,1.95,'Local CSV files','Centre attributes\nClosure events\nWalking-distance matrix')
s.shapes[-3].name='!!Runtime'
s.shapes[-2].name='!!RuntimeLabel'
line(s,3.2,3.55,4,3.55);line(s,8.7,3.55,9.5,3.55)
rect(s,4.0,5.5,8.6,.8,None,G);txt(s,'VERIFIED HERE  /  local Streamlit process + Python environment',4.24,5.75,8.1,.3,13,C,name='!!CloudFocus')
txt(s,'No database, live ingestion API, autoscaler or production cloud endpoint is evidenced in the repository.',.73,6.55,11.8,.3,11,G)
note(s,'Implemented technical architecture',"The browser communicates with one Streamlit application process. The entry point registers three pages through st.navigation. Python and Pandas handle the tabular data, and Plotly supplies the interactive charts. Selected loaders use Streamlit caching. Data storage is file based: local CSV files, not a managed database. There is no live ingestion API, authentication service or autoscaling configuration in the repository. We have verified this local process inside the development environment. That is different from publishing the application for end users. A running cloud development workspace does not establish a deployed product endpoint, an availability target or production scaling behavior.",50)

# 10 — Methodology (placed after data preparation in final order)
s=base(10,False,'Approach & Methodology')
txt(s,'Turn dates into decisions.',.65,1.04,11.9,.9,43,B,SER)
txt(s,'Transparent rules connect every input to a visible result.',.7,2.12,11.7,.6,21,INK,SER)
table=s.shapes.add_table(5,3,Inches(.7),Inches(3.03),Inches(11.9),Inches(3.36)).table
for c,w in zip(table.columns,[2.1,5.25,4.55]):c.width=Inches(w)
rows=[['STEP','IMPLEMENTED METHOD','DECISION SUPPORTED'],['1  Structure','Reshape quarterly date pairs into events; parse dates and flag invalid ranges','Separate dated schedules from records needing review'],['2  Filter','Match area, centre and closure type; retain overlapping date ranges','See which scheduled closures affect a visit'],['3  Compare','Use the included walking-distance matrix; rank three centres without a recorded closure','Find a nearby alternative for the selected day'],['4  Interpret','Add food and market stalls; compare totals and composition','Understand what centre size represents']]
for i,row in enumerate(rows):
 for j,val in enumerate(row):
  cell=table.cell(i,j);cell.text=val;cell.margin_left=Inches(.15);cell.margin_right=Inches(.12);cell.margin_top=Inches(.11);cell.margin_bottom=Inches(.08)
  cell.fill.solid();cell.fill.fore_color.rgb=rgb(B if i==0 else WHITE)
  for para in cell.text_frame.paragraphs:para.font.name=SANS;para.font.size=Pt(11 if i==0 else 12);para.font.bold=(i==0 or j==0);para.font.color.rgb=rgb(C if i==0 else INK)
 table.rows[i].height=Inches(.49 if i==0 else .72)
txt(s,'Rules are descriptive and schedule-based. No prediction model, live status feed or food-quality score is implemented.',.73,6.65,11.9,.25,10,M)
note(s,'Approach and methodology',"Our methodology uses transparent rules rather than a prediction model. First, reshape each centre's quarterly cleaning dates and other works into event records. Parse valid date ranges, calculate inclusive duration and retain incomplete records for review. Second, filter by area, centre and closure type, keeping events whose date ranges overlap the selected visit period. Third, use the included walking-distance matrix to rank three alternative centres with no closure recorded on the chosen day. Finally, calculate total stalls and compare their food and market composition. These descriptive methods make the dashboard explainable. They do not predict food quality, popularity or real-time availability. The following architecture slide shows how those rules are implemented.",55)

# 11 — Limitations
s=base(11,False,'10 / Limitations and next steps')
txt(s,'Make the next version\nmore trustworthy.',.65,1.0,11.5,1.55,44,B,SER)
items=[('01','FRESHNESS','Schedules can change.\n“Open” means no recorded closure.','Next: dated refreshes + official notices.'),('02','LINEAGE','Source URLs and licences are incomplete.\nArea groups use approximate keywords.','Next: verified sources + provenance.'),('03','REPRODUCIBILITY','Walking precompute paths\nand filename differ from\nthe app’s files.','Next: repair the pipeline + add tests.')]
for i,(n,h,body,nxt) in enumerate(items):
 x=.7+i*4.18;line(s,x,3.05,x+3.6,3.05,G);txt(s,n,x,3.3,1,.8,48,G,SER);txt(s,h,x,4.25,3.65,.4,16,B,bold=True);txt(s,body,x,4.85,3.65,.85,14,INK);txt(s,nxt,x,6.08,3.65,.5,12,M)
note(s,'Limitations and roadmap',"Three limitations define the next version. First is freshness. The app uses uploaded schedules; the Explore heading says live operational status, but there is no live feed. No recorded closure does not guarantee that every stall is open. Second is lineage: verify the source URLs, licences and publication dates, and replace approximate area grouping if official boundaries are needed. Third is reproducibility: the walking-distance precompute script expects different paths and an output filename that differ from the runtime files. The distance matrix is included, so the app runs, but regeneration is incomplete. External map tiles were also blocked here. These are genuine limitations, not hidden by the demo.",50)

# 12 — Close
s=base(12,True,'The impact / a clearer visit decision')
txt(s,'HAWKERGO',.58,1.18,12.0,1.6,92,C,SER,name='!!BrandTitle')
txt(s,'Explore More.\nDiscover Better.',.7,3.12,7.5,1.7,46,C,SER)
line(s,8.8,3.12,8.8,6.48,G)
txt(s,'CHECK THE DATE.\nFIND AN ALTERNATIVE.\nUNDERSTAND THE OPTIONS.',9.2,3.25,3.3,1.4,17,C)
txt(s,'Madhu · Nicolyne Tiana Lie · Enhui',.73,5.5,7.9,.4,15,G)
t=txt(s,'github.com/nicolynetiana/\nHawkerGO_DS608_project',.73,6.1,7.9,.6,14,C)
for q in t.text_frame.paragraphs:
 for run in q.runs:
  run.hyperlink.address='https://github.com/nicolynetiana/HawkerGO_DS608_project'
  run.font.color.rgb=rgb(C);run.font.underline=False
txt(s,'Working local demo verified.\nNo production app link verified.',9.2,5.72,3.0,.6,12,G)
note(s,'Closing',"HawkerGO turns a collection of public schedules and centre attributes into a clearer visit decision. The experience connects three questions: when should I go, where could I go instead, and what kinds of stalls will I find? We have demonstrated the working local application and explained the data preparation and rules behind its results. The next priorities are trustworthy refreshes, documented data lineage and a reproducible deployment. The repository is linked on screen. Thank you. We welcome questions about the filtering logic, the meaning of scheduled status, and which operational improvements should come first.",30)

# Final content order: motivation, data, methodology, dashboard, limitations.
order=[0,1,2,7,9,8,3,4,5,6,10,11]
slide_ids=list(p.slides._sldIdLst)
for sid in slide_ids:p.slides._sldIdLst.remove(sid)
for index in order:p.slides._sldIdLst.append(slide_ids[index])
notes=[notes[i] for i in order]
for number,slide in enumerate(p.slides,1):
 for shape in slide.shapes:
  if shape.name=='SlideNumber':shape.text_frame.paragraphs[0].runs[0].text=f'{number:02}'
# Hyperlink colours also follow the burgundy/cream palette in office renderers.
from lxml import etree
for part in p.part.package.iter_parts():
 if str(part.partname)=='/ppt/theme/theme1.xml':
  theme=etree.fromstring(part.blob)
  for tag in ['hlink','folHlink']:
   elem=theme.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}'+tag)
   for child in elem:elem.remove(child)
   col=OxmlElement('a:srgbClr');col.set('val',C);elem.append(col)
  part._blob=etree.tostring(theme,xml_declaration=True,encoding='UTF-8',standalone=True)
p.save(ROOT/'HawkerGO_Final_Presentation.pptx')
# Complete speaker script; timing includes silent video playback.
head='''# HawkerGO — presentation script\n\nTarget: approximately 10 minutes including the 73.2-second video. The suggested allocations total 580 seconds; allow a short buffer for handoffs and starting playback.\n\nCourse title follows the user's request: DS608 Cloud Computing. The attached project guide and repository instead label DS608 Data Analytics for Economics. Confirm the administrative title before assessment. Group names follow README and CONTRIBUTIONS; Enhui has no verified surname in those files.\n\nThis presentation and its recording/editing scripts were created with generative AI assistance, based on inspected code and genuine browser footage. The team should review, understand and acknowledge this assistance in its submission. Repository AI_USAGE.md is currently empty and was left unchanged.\n\n'''
(ROOT/'HawkerGO_Presentation_Script.md').write_text(head+'\n\n'.join(f'## {i+1:02}. {t} — {sec}s\n\n{body}' for i,(t,body,sec) in enumerate(notes)))
print('Saved',len(p.slides),'editable slides')
