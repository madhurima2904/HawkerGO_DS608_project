from pathlib import Path
import json,threading,functools
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
f=R/'source/player_test.html'
f.write_text('<!doctype html><meta charset="utf-8"><video controls muted src="../HawkerGO_Demo_Video.mp4"></video>')
handler=functools.partial(SimpleHTTPRequestHandler,directory=str(R))
server=ThreadingHTTPServer(('127.0.0.1',8765),handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page();page.goto('http://127.0.0.1:8765/source/player_test.html');page.wait_for_function('document.querySelector("video").readyState >= 2')
 info=page.eval_on_selector('video','v=>({duration:v.duration,width:v.videoWidth,height:v.videoHeight,error:v.error})')
 page.eval_on_selector('video','v=>{v.playbackRate=8;return v.play()}');page.wait_for_timeout(1800)
 time=page.eval_on_selector('video','v=>v.currentTime');assert time>3
 info['playback_advanced_to_seconds']=time;info['status']='passed';print(info)
 (R/'source/browser_playback.json').write_text(json.dumps(info,indent=2));b.close()

server.shutdown()
