# Evidence ledger

Inspected repository: `nicolynetiana/HawkerGO_DS608_project`, local HEAD `ae570c5cdd0ab11aa80ca49915bf564774d37062`.

| Claim / material | Evidence |
|---|---|
| Group names | README: Madhurima Subramaniam Rudra, Nicolyne Tiana Lie, Enhui; CONTRIBUTIONS identifies Madhu's page responsibility |
| Three pages, default Calendar | app.py, `st.Page` and `st.navigation` |
| Explore filters and details | pages/1_Explore_Hawkers.py: date input, MRT selector, status multiselect, selected-centre selector, detail cards |
| Scheduled status, not live telemetry | `enrich` / `closed_between` compute closure status from date columns; no live ingestion call |
| Nearest alternatives | `load_walk_matrix`, name-mapped row, three smallest distances excluding selected/recorded-closed centres |
| Chomp Chomp June example | Both raw and processed CSV files record 22–24 June 2026 cleaning; verified in actual browser |
| Serangoon Garden example | Actual alternative finder result for 22 June 2026 / Lorong Chuan, captured in alternatives.png |
| Calendar behavior | pages/2_Maintenance_Calendar.py: area grouping, overlap filters, heatmap, records needing confirmation |
| Stall composition and chart | pages/3_Stall_Insights.py plus data/processed/hawker_centres_final.csv; counts recalculated in project_evidence.py |
| 123 centre rows | Included raw closure CSV and processed centre CSV |
| 539 events, 513 dated, 26 review | src/wrangle.py / load_closure_data(); recomputed for this task |
| Local caching | `st.cache_data` in page loaders; not a cross-instance cache claim |
| Local storage | CSV file paths in each page; no managed database configuration inspected |
| Reproducibility limitation | src/precompute_walk.py uses `src/data-processed` and `src/data-raw` paths, an unavailable OSM input and a different output filename from runtime `hc_walk_distances.csv` |
| Source and licence limitations | README asks to verify and add original dataset URLs, publication dates and licences |
| Presentation scope / timing | DS608 Group Project Guide, Final Presentation section: 10 minutes, then discussant feedback and Q&A |
| Course-title discrepancy | Guide title and repository say Data Analytics for Economics; user's direct request says Cloud Computing, which is used on the deck |
| Visual reference limitation | DS608_HawkerGO.pdf transfer rejected above 32 MiB. No pages were inspected; visual style follows the user's written design specification |
| Cloud services | No production endpoint, provider deployment manifest, database, monitoring or autoscaling was verified; cloud additions are explicitly proposed |

No user-impact experiment, uptime benchmark, concurrency result, cost comparison or production deployment is asserted. The finished presentation and recording should be reviewed by the project team for academic submission. The reference PDF and repository files were not modified; no generated media was committed or pushed.
