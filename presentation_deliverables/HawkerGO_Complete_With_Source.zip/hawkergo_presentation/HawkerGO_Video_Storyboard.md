# HawkerGO — finished video storyboard

**73.2 seconds · 1920 × 1080 · 30 fps · H.264 / yuv420p · silent**

All application imagery originates from genuine Chromium recordings of the local Streamlit app at repository commit `ae570c5cdd0ab11aa80ca49915bf564774d37062`. The app's DOM, CSS, data and interface were not modified for filming. Reframing, subtitles, crossfades and subtle zooms were added in the edit. No music, narration, stock photographs, fabricated interfaces or watermarks are used. Original interface emoji icons remain part of the recorded app; no emoji were added to the editing graphics.

| Final time | Scene | Genuine action / visible result |
|---|---|---|
| 0:00–0:06 | Burgundy opening | Product title and tagline |
| 0:05.6–0:13.6 | Maintenance overview | Read the Serangoon view; scroll towards filters |
| 0:13.2–0:25.2 | Choose a month | Change October to June 2026; cleaning days change to 22–24 |
| 0:24.8–0:30.8 | Closure detail | Read Chomp Chomp's 22–24 June cleaning record |
| 0:30.4–0:42.4 | Explore filters | Set 22 June 2026; search and select Lorong Chuan MRT; counters update |
| 0:42.0–0:54.0 | Alternative finder | Chomp Chomp marked closed; Serangoon Garden listed about 0.1 km away |
| 0:53.6–1:05.6 | Stall Insights | Inspect chart; open the top-ten table and scroll to the data |
| 1:05.2–1:13.2 | Closing | Product tagline and reminder to check official notices |

The 0.4-second overlaps are intentional crossfades. English captions are burned into the chapter frames; the SRT also supplies opening and closing text. The scenario uses historical scheduled dates from the included data. It does not assert real-time opening status. Basemap requests and Google fonts were blocked by the environment network policy, so the video focuses on the working calendar, filters, details, alternatives and charts.

## Re-recording and editing

See `source/README.md`. `source/record_demo.py` records native browser interactions and writes exact source-time markers. `source/edit_video.py` uses those markers for trims, pace, proportional crops, subtle zooms, crossfades, branded cards, SRT export and MP4 encoding. The original browser recording and intermediate clips are retained under `source/recordings/`.
