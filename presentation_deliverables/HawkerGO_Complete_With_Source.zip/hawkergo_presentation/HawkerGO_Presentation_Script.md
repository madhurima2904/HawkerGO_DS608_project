# HawkerGO — presentation script

Target: approximately 10 minutes including the 73.2-second video. The suggested allocations total 580 seconds; allow a short buffer for handoffs and starting playback.

Course title follows the user's request: DS608 Cloud Computing. The attached project guide and repository instead label DS608 Data Analytics for Economics. Confirm the administrative title before assessment. Group names follow README and CONTRIBUTIONS; Enhui has no verified surname in those files.

This presentation and its recording/editing scripts were created with generative AI assistance, based on inspected code and genuine browser footage. The team should review, understand and acknowledge this assistance in its submission. Repository AI_USAGE.md is currently empty and was left unchanged.

## 01. Opening — 40s

A good hawker visit starts before we leave home. HawkerGO brings scheduled closures, nearby alternatives and stall information into one Streamlit dashboard. Our focus is practical: help a resident check a plan and find another option when a favourite centre is scheduled to close. This is a group project by Madhurima Subramaniam Rudra, known as Madhu, Nicolyne Tiana Lie and Enhui. Today we will follow five sections: motivation and objectives, data sources and preparation, approach and methodology, the dashboard, and challenges and limitations.

## 02. The problem — 45s

The problem is a decision, rather than a lack of restaurant recommendations. A resident may know where they want to eat but still need to know whether a scheduled cleaning period overlaps their visit. If it does, they need another centre nearby. A large centre is also not automatically the best choice for cooked food: total stalls combine food and market stalls. Our research question is how public closure data can be transformed into an interactive dashboard for visit planning. We do not estimate wasted journeys or claim measured time savings; those would require separate user research.

## 03. Meet HawkerGO — 45s

HawkerGO combines three views of the same planning problem. Explore Hawkers supports date, MRT and status filtering, centre details and nearby alternatives. The Maintenance Calendar presents cleaning and other works over time. Stall Insights compares the distribution of food and market stalls. There are 123 centre records in the included processed dataset. These are dataset coverage figures, not a claim about complete current national coverage. The screenshot is captured from the working app. Its status labels are computed from uploaded schedules, so they must not be interpreted as a live operational feed.

## 04. Data and preparation — 50s

The repository includes a raw closure CSV with 123 centre records, plus hawker-centre and MRT-exit GeoJSON files. The closure loader in src/wrangle.py reshapes quarterly cleaning and other-works date pairs into 539 event records. Of these, 513 have valid date ranges and 26 require review. It parses day-month-year dates, computes inclusive duration and retains remarks. The Explore and Stall Insights pages read the processed centre CSV; the alternative finder also reads a 123-by-123 distance matrix. The complete lineage of those processed files is not documented. Original dataset URLs, publication dates and licences remain a verification task; we do not invent them here.

## 05. Approach and methodology — 55s

Our methodology uses transparent rules rather than a prediction model. First, reshape each centre's quarterly cleaning dates and other works into event records. Parse valid date ranges, calculate inclusive duration and retain incomplete records for review. Second, filter by area, centre and closure type, keeping events whose date ranges overlap the selected visit period. Third, use the included walking-distance matrix to rank three alternative centres with no closure recorded on the chosen day. Finally, calculate total stalls and compare their food and market composition. These descriptive methods make the dashboard explainable. They do not predict food quality, popularity or real-time availability. The following architecture slide shows how those rules are implemented.

## 06. Implemented technical architecture — 50s

The browser communicates with one Streamlit application process. The entry point registers three pages through st.navigation. Python and Pandas handle the tabular data, and Plotly supplies the interactive charts. Selected loaders use Streamlit caching. Data storage is file based: local CSV files, not a managed database. There is no live ingestion API, authentication service or autoscaling configuration in the repository. We have verified this local process inside the development environment. That is different from publishing the application for end users. A running cloud development workspace does not establish a deployed product endpoint, an availability target or production scaling behavior.

## 07. The user journey — 40s

Here is the journey demonstrated in the video. First, check the Maintenance Calendar for Serangoon in June 2026. It records a Chomp Chomp cleaning closure from the twenty-second to the twenty-fourth. Next, set the Explore page to the twenty-second of June and filter for Lorong Chuan MRT. The selected centre is marked closed according to that schedule. Finally, inspect the alternative finder: Serangoon Garden Market is listed about one tenth of a kilometre away. This is an illustrative historical scenario from the supplied data, rather than advice that either centre is open right now. Distances and walking times are estimates.

## 08. Explore Hawkers — 50s

Explore Hawkers begins with the visit date, an MRT station, a status filter and a selected centre. The summary cards update for the MRT-filtered group. The detail card shows address, scheduled status, future cleaning information, stall counts and an estimated walk from the nearest MRT. The alternative finder uses an included centre-to-centre distance matrix and ranks three centres that have no closure recorded for the selected day. The implementation does not ask a routing service for each visit. The map is implemented in Plotly, but external basemap requests are blocked in this recording environment, so the demonstration focuses on the working controls and detail cards.

## 09. What stall counts reveal — 45s

The Stall Insights page gives us a useful analytical distinction. In the included data, Chinatown Complex has the largest total count: 703 stalls. That comprises 226 food stalls and 477 market stalls. So ranking only by total size can obscure what a visitor wants to do. The stacked bars make the composition visible, while the app also provides a top-ten table and a scatter plot of food versus market stalls. These counts describe the dataset, not popularity, food quality or sales. In this slide the chart is a native editable PowerPoint chart with its underlying values, rather than an image of a chart.

## 10. Demo — play video — 80s

Play the embedded video. The silent, captioned recording shows genuine interactions with the locally running Streamlit application: choose June, read the cleaning dates, filter Explore Hawkers by date and MRT, inspect the alternative finder, and open the stall-count table. Allow the complete 73.2-second clip to finish. Do not speak over the subtitles unless clarification is useful. After playback, explain that the example uses scheduled status rather than a real-time feed.

## 11. Limitations and roadmap — 50s

Three limitations define the next version. First is freshness. The app uses uploaded schedules; the Explore heading says live operational status, but there is no live feed. No recorded closure does not guarantee that every stall is open. Second is lineage: verify the source URLs, licences and publication dates, and replace approximate area grouping if official boundaries are needed. Third is reproducibility: the walking-distance precompute script expects different paths and an output filename that differ from the runtime files. The distance matrix is included, so the app runs, but regeneration is incomplete. External map tiles were also blocked here. These are genuine limitations, not hidden by the demo.

## 12. Closing — 30s

HawkerGO turns a collection of public schedules and centre attributes into a clearer visit decision. The experience connects three questions: when should I go, where could I go instead, and what kinds of stalls will I find? We have demonstrated the working local application and explained the data preparation and rules behind its results. The next priorities are trustworthy refreshes, documented data lineage and a reproducible deployment. The repository is linked on screen. Thank you. We welcome questions about the filtering logic, the meaning of scheduled status, and which operational improvements should come first.